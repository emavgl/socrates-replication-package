var EIP20 = artifacts.require("./PKT.sol");

module.exports = function(deployer) {
  deployer.deploy(EIP20);
};
