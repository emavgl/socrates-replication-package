var EIP20 = artifacts.require("./Amorcoin.sol");

module.exports = function(deployer) {
  deployer.deploy(EIP20);
};
