var EIP20 = artifacts.require("./FansChainToken.sol");

module.exports = function(deployer) {
  deployer.deploy(EIP20);
};
