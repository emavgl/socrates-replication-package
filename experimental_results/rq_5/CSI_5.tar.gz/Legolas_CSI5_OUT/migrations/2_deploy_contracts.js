var EIP20 = artifacts.require("./Legolas.sol");

module.exports = function(deployer) {
  deployer.deploy(EIP20);
};
