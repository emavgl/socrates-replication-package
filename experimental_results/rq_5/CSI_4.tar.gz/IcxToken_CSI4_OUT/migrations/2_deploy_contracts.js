var EIP20 = artifacts.require("./IcxToken.sol");

module.exports = function(deployer) {
  deployer.deploy(EIP20);
};
